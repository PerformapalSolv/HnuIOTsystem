import json
from django.shortcuts import render
from .models import Twenshidu
from datetime import datetime, timedelta
from django.http import JsonResponse

def T_wenshidu_data(request):
    wenshidu_data = Twenshidu.objects.order_by('-eventtime')[:50]
    data = {
        'labels': [
            (datetime.strptime(item.eventtime, '%Y%m%dT%H%M%SZ') + timedelta(hours=8)).strftime('%Y/%m/%d %H:%M:%S') for
            item in wenshidu_data],
        'temperatures': [item.temperature for item in wenshidu_data],
        'humidities': [item.humidity for item in wenshidu_data]
    }
    data['labels'] = data['labels'][::-1]
    data['temperatures'] = data['temperatures'][::-1]
    data['humidities'] = data['humidities'][::-1]
    current_data = {
        'label': data['labels'][-1],
        'temperature': data['temperatures'][-1],
        'humidity': data['humidities'][-1]
    }

    # 计算历史最高温度、最低温度、最高湿度和最低湿度
    max_temp_index = data['temperatures'].index(max(data['temperatures']))
    min_temp_index = data['temperatures'].index(min(data['temperatures']))
    max_humi_index = data['humidities'].index(max(data['humidities']))
    min_humi_index = data['humidities'].index(min(data['humidities']))

    history_data = {
        'max_temp': {
            'value': data['temperatures'][max_temp_index],
            'time': data['labels'][max_temp_index]
        },
        'min_temp': {
            'value': data['temperatures'][min_temp_index],
            'time': data['labels'][min_temp_index]
        },
        'max_humi': {
            'value': data['humidities'][max_humi_index],
            'time': data['labels'][max_humi_index]
        },
        'min_humi': {
            'value': data['humidities'][min_humi_index],
            'time': data['labels'][min_humi_index]
        }
    }

    # 计算异常日志
    abnormal_logs = []
    for i in range(len(data['labels'])):
        if data['temperatures'][i] < 20 or data['temperatures'][i] > 30:
            abnormal_logs.append(f"温度异常: {data['temperatures'][i]}°C, 时间: {data['labels'][i]}")
        if data['humidities'][i] < 40 or data['humidities'][i] > 60:
            abnormal_logs.append(f"湿度异常: {data['humidities'][i]}%, 时间: {data['labels'][i]}")

    return JsonResponse({
        'data': data,
        'current_data': current_data,
        'history_data': history_data,
        'abnormal_logs': abnormal_logs
    })

def T_wenshidu_chart(request):
    return render(request, 'wenshidu_chart.html')