from django.apps import AppConfig


class TruewsduConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'TrueWSdu'
