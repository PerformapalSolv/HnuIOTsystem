from django.urls import path
from . import views

urlpatterns = [
    path('wsduchart/', views.T_wenshidu_chart),
    path('data/', views.T_wenshidu_data, name='T_wenshidu_data'),
]