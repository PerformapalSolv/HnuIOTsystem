# views.py
from django.shortcuts import render
from .models import Wenshiduinfo
from django.http import JsonResponse
from datetime import datetime, timedelta
import json

infrared_logs = []


def infrared_data(request):
    global infrared_logs
    wenshidu_data = Wenshiduinfo.objects.order_by('-eventtime')[:50]
    data = {
        'labels': [
            (datetime.strptime(item.eventtime, '%Y%m%dT%H%M%SZ') + timedelta(hours=8)).strftime('%Y/%m/%d %H:%M:%S') for
            item in wenshidu_data],
        'duration': [item.isSomeone for item in wenshidu_data],
    }
    data['labels'] = data['labels'][::-1]
    data['duration'] = data['duration'][::-1]

    current_time = data['labels'][-1] if data['labels'] else None
    is_someone = data['duration'][-1] if data['duration'] else None

    # 更新红外日志
    if is_someone:  # 如果当前监测到人
        if not infrared_logs or not infrared_logs[-1]['is_detecting']:  # 如果之前没有监测到人,或者上一次监测已经结束
            infrared_logs.append({
                'start_time': current_time,
                'duration': 0.1,
                'is_detecting': True
            })
        else:  # 如果之前已经开始监测到人
            infrared_logs[-1]['duration'] = (datetime.strptime(current_time, '%Y/%m/%d %H:%M:%S') - datetime.strptime(
                infrared_logs[-1]['start_time'], '%Y/%m/%d %H:%M:%S')).total_seconds()
    else:  # 如果当前没有监测到人
        if infrared_logs and infrared_logs[-1]['is_detecting']:  # 如果之前正在监测到人
            infrared_logs[-1]['is_detecting'] = False

    current_data = {
        'label': current_time,
        'is_someone': is_someone,
    }

    total_duration = sum(log['duration'] for log in infrared_logs)

    return JsonResponse({
        'current_data': current_data,
        'infrared_logs': infrared_logs,
        'total_duration': total_duration
    })


def infrared_chart(request):
    return render(request, 'infrared_chart.html')