from django.db import models
import json

class Wenshiduinfo(models.Model):
    eventtime = models.CharField(primary_key=True,max_length=16)
    comment = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'wenshiduinfo'


    @property
    def isSomeone(self):
        info_dict = json.loads(self.comment)
        return info_dict[0]['properties']['yoren']

