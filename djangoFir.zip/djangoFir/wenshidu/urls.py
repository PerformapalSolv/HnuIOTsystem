from django.urls import path
from . import views

urlpatterns = [
    path('people-data/', views.infrared_data, name='infrared_data'),
    path('people-chart/', views.infrared_chart, name='infrared_chart'),
]