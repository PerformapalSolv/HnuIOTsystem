from django.shortcuts import render
import serial
import threading
import serial.tools.list_ports
from datetime import datetime, timedelta, timezone
from django.http import JsonResponse


lock = threading.Lock()
STC_events = []
ser = serial.Serial(list(serial.tools.list_ports.comports()[0])[0], 1200, timeout=0.15)
beijing_tz = timezone(timedelta(hours=8))

class ReadThread(threading.Thread):
   def __init__(self, n):
      self.n = n
      self.chs = []
      self.stc_event = []
      super().__init__()

   def run(self) -> None:
      while True:
         self.chs = list(ser.read(6))
         if len(self.chs):
            if self.chs[0] == 0xa5:
               self.stc_event = []  # Clear the list before appending new data
               self.stc_event.append(datetime.now(beijing_tz).strftime("%Y-%m-%d %H:%M:%S"))
               self.stc_event.append((self.chs[1]*100+self.chs[2]*10+self.chs[3]))
               self.stc_event.append(self.chs[4])
               self.stc_event.append(self.chs[5])
               with lock:
                   STC_events.append(self.stc_event)
               if len(STC_events) > 50:
                  with lock:
                      del STC_events[0]


the_read_thread = ReadThread(1)
the_read_thread.daemon = True
the_read_thread.start()


def get_light_data(request):
   global STC_events
   with lock:
      # 获取最新的光照数据和时间
      light_data = [event[1] for event in STC_events]
      time_data = [event[0] for event in STC_events]
      # 获取当前光照信息和时间
      current_light = STC_events[-1][1] if len(STC_events) else None
      current_time = STC_events[-1][0] if len(STC_events) else None

      # 记录异常次数和日志
      abnormal_count = 0
      abnormal_logs = []
      for i, light in enumerate(light_data):
         if light > 200:  # 假设光照强度低于100视为异常
            abnormal_count += 1
            abnormal_logs.append(f"{light} lux at {time_data[i]}")

   # 返回 JSON 格式的数据
   data = {
      'light_data': light_data,
      'time_data': time_data,
      'current_light': current_light,
      'current_time': current_time,
      'abnormal_count': abnormal_count,
      'abnormal_logs': abnormal_logs,
   }
   return JsonResponse(data)


def lightsee(request):
   global STC_events

   # 获取光照数据和时间
   with lock:
      light_data = [event[1] for event in STC_events]
      time_data = [event[0] for event in STC_events]
      # 获取当前光照信息和时间
      current_light = STC_events[-1][1] if len(STC_events) else None
      current_time = STC_events[-1][0] if len(STC_events) else None

      # 记录异常次数和日志
      abnormal_count = 0
      abnormal_logs = []
      for i, light in enumerate(light_data):
         if light > 200:  # 假设光照强度低于100视为异常
            abnormal_count += 1
            abnormal_logs.append(f"{light} lux at {time_data[i]}")

   # 渲染HTML模板,将数据传递给模板
   return render(request, 'lightsee.html',
                 {'light_data': light_data, 'time_data': time_data, 'current_light': current_light,
                  'current_time': current_time, 'abnormal_count': abnormal_count, 'abnormal_logs': abnormal_logs})


vib_logs = []

def get_vib_data(request):
    global STC_events, vib_logs
    with lock:
        # 获取当前时间和是否振动的信息
        current_time = STC_events[-1][0] if len(STC_events) else None
        is_vib = STC_events[-1][3] if len(STC_events) else None

        # 更新振动日志
        if is_vib:  # 如果当前正在振动
            if not vib_logs or not vib_logs[-1]['is_vibrating']:  # 如果之前没有振动,或者上一次振动已经结束
                vib_logs.append({
                    'start_time': current_time,
                    'duration': 0.1,
                    'is_vibrating': True
                })
            else:  # 如果之前已经开始振动
                vib_logs[-1]['duration'] = (datetime.strptime(current_time, '%Y-%m-%d %H:%M:%S') - datetime.strptime(vib_logs[-1]['start_time'], '%Y-%m-%d %H:%M:%S')).total_seconds()
        else:  # 如果当前没有振动
            if vib_logs and vib_logs[-1]['is_vibrating']:  # 如果之前正在振动
                vib_logs[-1]['is_vibrating'] = False

    # 返回 JSON 格式的数据
    data = {
        'current_time': current_time,
        'is_vib': is_vib,
        'vib_logs': vib_logs
    }
    return JsonResponse(data)


def vibsee(request):
    global STC_events, vib_logs

    # 获取当前时间和是否振动的信息
    with lock:
        current_time = STC_events[-1][0] if len(STC_events) else None
        is_vib = STC_events[-1][3] if len(STC_events) else None

    # 渲染HTML模板,将数据传递给模板
    return render(request, 'vibsee.html',
                  {'current_time': current_time, 'is_vib': is_vib, 'vib_logs': vib_logs})


hall_logs = []

def get_hall_data(request):
   global STC_events, hall_logs
   with lock:
      # 获取当前时间和是否有磁场异常的信息
      current_time = STC_events[-1][0] if len(STC_events) else None
      is_hall = STC_events[-1][2] if len(STC_events) else None

      # 更新磁场异常日志
      if is_hall:  # 如果当前有磁场异常
         if not hall_logs or not hall_logs[-1]['is_abnormal']:  # 如果之前没有异常,或者上一次异常已经结束
            hall_logs.append({
               'start_time': current_time,
               'duration': 0.1,
               'is_abnormal': True
            })
         else:  # 如果之前已经开始异常
            hall_logs[-1]['duration'] = (datetime.strptime(current_time, '%Y-%m-%d %H:%M:%S') - datetime.strptime(hall_logs[-1]['start_time'], '%Y-%m-%d %H:%M:%S')).total_seconds()
      else:  # 如果当前没有异常
         if hall_logs and hall_logs[-1]['is_abnormal']:  # 如果之前有异常
            hall_logs[-1]['is_abnormal'] = False

   # 返回 JSON 格式的数据
   data = {
      'current_time': current_time,
      'is_hall': is_hall,
      'hall_logs': hall_logs
   }
   return JsonResponse(data)

def hallsee(request):
   global STC_events, hall_logs

   # 获取当前时间和是否有磁场异常的信息
   with lock:
      current_time = STC_events[-1][0] if len(STC_events) else None
      is_hall = STC_events[-1][2] if len(STC_events) else None

   # 渲染HTML模板,将数据传递给模板
   return render(request, 'hallsee.html',
                 {'current_time': current_time, 'is_hall': is_hall, 'hall_logs': hall_logs})


def test(request):
   return render(request, 'myindex.html')