from django.urls import path
from . import views

urlpatterns = [
    path('light/', views.lightsee),
    path('get_light_data/', views.get_light_data, name='get_light_data'),
    path('vibsee/', views.vibsee, name='vibsee'),
    path('get_vib_data/', views.get_vib_data, name='get_vib_data'),
    path('hallsee/', views.hallsee, name='hallsee'),
    path('get_hall_data/', views.get_hall_data, name='get_hall_data'),
    path('test/', views.test, name='test'),
]