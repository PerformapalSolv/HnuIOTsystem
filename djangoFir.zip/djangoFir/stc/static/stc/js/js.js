﻿var myChart1 = echarts.init(document.getElementById('echarts1'));
var myChart2 = echarts.init(document.getElementById('echarts2'));
var dom = document.getElementById('echarts3');

var myChart3 = echarts.init(dom, null, {
    renderer: 'canvas',
    useDirtyRect: false
});

var option1 = {
    tooltip: {
        trigger: 'axis',
        axisPointer: {
            type: 'shadow'
        }
    },
    // legend: {
    //     data: ['文本1', '文本2'],

    //     top: '2%',
    //     textStyle: {
    //         color: "rgba(255,255,255,.5)",
    //         fontSize: '12',

    //     },
    //     itemWidth: 12,
    //     itemHeight: 12,
    //     itemGap: 35
    // },
    grid: {
        left: '0%',
        top: '10px',
        right: '10px',
        bottom: '0%',
        containLabel: true
    },
    xAxis: [{
        type: 'category',
        
        data: ['1', '2', '3', '4', '5', '6', '7', '8', '9'],
        axisLine: {
            show: true,
            lineStyle: {
                color: "rgba(255,255,255,.1)",
                width: 1,
                type: "solid"
            },
        },

        axisTick: {
            show: false,
        },
        axisLabel: {
            // interval: 0,
            // rotate:50,
            show: true,
            splitNumber: 15,
            textStyle: {
                color: "rgba(255,255,255,.6)",
                fontSize: '12',
            },
        },
    }],
    yAxis: [{
        type: 'value',
        splitNumber: 2,
        axisLabel: {
            //formatter: '{value} %'
            show: true,
            textStyle: {
                color: "rgba(255,255,255,.6)",
                fontSize: '12',
            },
        },
        axisTick: {
            show: false,
        },
        axisLine: {
            show: false,
        },
        splitLine: {
            show: true,
            lineStyle: {
                color: "rgba(255,255,255,.1)",
            }
        }
    }],
    series: [
        {
            name: '',
            type: 'bar',
            data: [2, 3, 3, 9, 15, 12, 6, 4, 6],
            barWidth: '15', 
            itemStyle: {
                normal: {
                    color: '#2f89cf',
                    opacity: 1,
                    barBorderRadius: 2,
                }
            }
        }
    ]
};

var option2 = {
    tooltip: {
        position: 'top'
    },
    grid: {
        left: '0%',
        top: '0px',
        right: '60',
        bottom: '0%',
        containLabel: true
    },
    xAxis: {
        type: 'category',
        data: [],
        axisLabel: {
            // formatter:function(value){return value.split("").join("\n");},
       textStyle: {
            color: "rgba(255,255,255,.6)",
           fontSize:12,
                 }
      },
        splitArea: {
            show: true
        }
    },
    yAxis: {
        type: 'category',
        data: [],
        axisLabel: {
       textStyle: {
            color: "rgba(255,255,255,.6)",
           fontSize:12,
                 }
      },
        splitArea: {
            show: true
        }
    },
    visualMap: {
        min: 0,
        max: 100,
        // color:'#fff',
        calculable: true,
        orient: 'vertical',
        right: '0',
        textStyle: {
            color: '#fff'
        },
        top: 'center',
        inRange: {
            color: [
                '#313695',
                '#4575b4',
                '#74add1',
                '#abd9e9',
                '#e0f3f8',
                '#ffffbf',
                '#fee090',
                '#fdae61',
                '#f46d43',
                '#d73027',
                '#a50026'
            ]
        }
      },
    // visualMap: {
    //     min: 0,
    //     max: 100,
    //     right: 0,
    //     top: "center",
    //     show: false,
    //     calculable: true,
    //     realtime: false,
    //     inRange: {
    //         color: [
    //             '#313695',
    //             '#4575b4',
    //             '#74add1',
    //             '#abd9e9',
    //             '#e0f3f8',
    //             '#ffffbf',
    //             '#fee090',
    //             '#fdae61',
    //             '#f46d43',
    //             '#d73027',
    //             '#a50026'
    //         ]
    //     }
    // },
    series: [
        {
            name: 'Punch Card',
            type: 'heatmap',
            data: [],
            label: {
                show: false
            },
            emphasis: {
                itemStyle: {
                    shadowBlur: 10,
                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
            }
        }
    ]
};


// 使用刚指定的配置项和数据显示图表。
window.addEventListener("resize", function () {
    myChart1.resize();
    myChart2.resize();
    myChart3.resize();
});